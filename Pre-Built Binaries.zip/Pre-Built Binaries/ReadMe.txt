By running DatasetCreation.exe file creating and saving shape images and respective .csv files will start. 

Note: If you do not have Visual Studio 2013 installed, please install the proper redistribution file before you proceed.

The procedure has two stages:
1) first train shapes are created 
2) then, test shapes are created.

The default values are as the following:

- 	The path into which the created images should be placed:
	
	* train_path = "Images/train/";
	* test_path  = "Images/test/";
	* The corresponding .csv files will be created in the current folder

	
- 	The number of images and their sizes:
	
	* the total number of train images:30000
	* the size of train images (700,700) 
		Note: in practice the size of images selected for training is much less than the above mentioned size
	* the total number of test images: 2000
	* the size of train images (900,700) 


	After showing these two messages the procedure ends.
	"Train dataset has been prepared!";
	"Test dataset has been prepared!";
	
 Reuirements:
 For running the .exe file you need to install the Visual C++ Redistributable Packages for Visual Studio 2013 x64 version (preferably Windows 7; however higher version will be ok) from the link below:
 https://www.microsoft.com/en-us/download/details.aspx?id=40784
	